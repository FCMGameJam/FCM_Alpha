// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "FCM_AlphaGameMode.h"
#include "My_FCM_AlphaGameMode.generated.h"

/**
 * 
 */
UCLASS()
class FCM_ALPHA_API AMy_FCM_AlphaGameMode : public AFCM_AlphaGameMode
{
	GENERATED_BODY()
	
};
